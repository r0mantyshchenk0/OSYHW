#define _GNU_SOURCE
#include <errno.h>
#include <limits.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

typedef struct Item {
    int count;
    char *text;
    struct Item *next;
} Item;

typedef struct {
    Item *head;
    Item *tail;
    pthread_mutex_t mutex;
    pthread_mutex_t output_mutex;
    sem_t items;
    int finished;
    int consumers;
    int producer_result;
} Shared;

typedef struct {
    Shared *shared;
    int id;
} ConsumerArgs;

static void finish_producer(Shared *shared, int result)
{
    pthread_mutex_lock(&shared->mutex);
    shared->finished = 1;
    shared->producer_result = result;
    pthread_mutex_unlock(&shared->mutex);

    for (int i = 0; i < shared->consumers; ++i)
        sem_post(&shared->items);
}

static void *producer(void *arg)
{
    Shared *shared = arg;
    int x;
    int ret;
    char *text = NULL;

    while ((ret = scanf("%d %ms", &x, &text)) == 2) {
        if (x < 0) {
            free(text);
            finish_producer(shared, 1);
            return NULL;
        }

        Item *item = malloc(sizeof(*item));
        if (item == NULL) {
            free(text);
            finish_producer(shared, 1);
            return NULL;
        }

        item->count = x;
        item->text = text;
        item->next = NULL;
        text = NULL;

        pthread_mutex_lock(&shared->mutex);
        if (shared->tail == NULL) {
            shared->head = item;
            shared->tail = item;
        } else {
            shared->tail->next = item;
            shared->tail = item;
        }
        pthread_mutex_unlock(&shared->mutex);

        sem_post(&shared->items);
    }

    if (ret != EOF)
        finish_producer(shared, 1);
    else
        finish_producer(shared, 0);

    return NULL;
}

static void *consumer(void *arg)
{
    ConsumerArgs *args = arg;
    Shared *shared = args->shared;

    while (1) {
        while (sem_wait(&shared->items) == -1 && errno == EINTR) {
        }

        pthread_mutex_lock(&shared->mutex);

        Item *item = shared->head;
        if (item != NULL) {
            shared->head = item->next;
            if (shared->head == NULL)
                shared->tail = NULL;
        }

        int finished = shared->finished;
        pthread_mutex_unlock(&shared->mutex);

        if (item == NULL) {
            if (finished)
                break;
            continue;
        }

        pthread_mutex_lock(&shared->output_mutex);
        printf("Thread %d:", args->id);
        for (int i = 0; i < item->count; ++i)
            printf(" %s", item->text);
        putchar('\n');
        pthread_mutex_unlock(&shared->output_mutex);

        free(item->text);
        free(item);
    }

    return NULL;
}

static int parse_consumers(int argc, char **argv, int max_cpus, int *value)
{
    if (argc == 1) {
        *value = 1;
        return 0;
    }

    if (argc != 2)
        return 1;

    char *end = NULL;
    errno = 0;
    long n = strtol(argv[1], &end, 10);

    if (errno != 0 || end == argv[1] || *end != '\0' || n < 1 ||
        n > max_cpus || n > INT_MAX)
        return 1;

    *value = (int)n;
    return 0;
}

int main(int argc, char **argv)
{
    long cpu_count = sysconf(_SC_NPROCESSORS_ONLN);
    if (cpu_count < 1 || cpu_count > INT_MAX)
        return 1;

    int n;
    if (parse_consumers(argc, argv, (int)cpu_count, &n) != 0)
        return 1;

    Shared shared = {
        .head = NULL,
        .tail = NULL,
        .finished = 0,
        .consumers = n,
        .producer_result = 0
    };

    if (pthread_mutex_init(&shared.mutex, NULL) != 0)
        return 1;
    if (pthread_mutex_init(&shared.output_mutex, NULL) != 0) {
        pthread_mutex_destroy(&shared.mutex);
        return 1;
    }
    if (sem_init(&shared.items, 0, 0) != 0) {
        pthread_mutex_destroy(&shared.output_mutex);
        pthread_mutex_destroy(&shared.mutex);
        return 1;
    }

    pthread_t producer_thread;
    pthread_t *consumer_threads = malloc((size_t)n * sizeof(*consumer_threads));
    ConsumerArgs *consumer_args = malloc((size_t)n * sizeof(*consumer_args));

    if (consumer_threads == NULL || consumer_args == NULL) {
        free(consumer_threads);
        free(consumer_args);
        sem_destroy(&shared.items);
        pthread_mutex_destroy(&shared.output_mutex);
        pthread_mutex_destroy(&shared.mutex);
        return 1;
    }

    if (pthread_create(&producer_thread, NULL, producer, &shared) != 0) {
        free(consumer_threads);
        free(consumer_args);
        sem_destroy(&shared.items);
        pthread_mutex_destroy(&shared.output_mutex);
        pthread_mutex_destroy(&shared.mutex);
        return 1;
    }

    int created = 0;
    for (int i = 0; i < n; ++i) {
        consumer_args[i].shared = &shared;
        consumer_args[i].id = i + 1;

        if (pthread_create(&consumer_threads[i], NULL, consumer, &consumer_args[i]) != 0)
            break;
        ++created;
    }

    if (created != n) {
        pthread_join(producer_thread, NULL);
        for (int i = 0; i < created; ++i)
            pthread_join(consumer_threads[i], NULL);

        Item *item = shared.head;
        while (item != NULL) {
            Item *next = item->next;
            free(item->text);
            free(item);
            item = next;
        }

        free(consumer_threads);
        free(consumer_args);
        sem_destroy(&shared.items);
        pthread_mutex_destroy(&shared.output_mutex);
        pthread_mutex_destroy(&shared.mutex);
        return 1;
    }

    pthread_join(producer_thread, NULL);
    for (int i = 0; i < n; ++i)
        pthread_join(consumer_threads[i], NULL);

    int result = shared.producer_result;

    free(consumer_threads);
    free(consumer_args);
    sem_destroy(&shared.items);
    pthread_mutex_destroy(&shared.output_mutex);
    pthread_mutex_destroy(&shared.mutex);

    return result;
}
