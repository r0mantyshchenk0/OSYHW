#define _POSIX_C_SOURCE 200809L

#include <pthread.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>

enum place {
    NUZKY, VRTACKA, OHYBACKA, SVARECKA, LAKOVNA, SROUBOVAK, FREZA,
    _PLACE_COUNT
};

static const char *place_str[_PLACE_COUNT] = {
    "nuzky", "vrtacka", "ohybacka", "svarecka", "lakovna", "sroubovak", "freza"
};

enum product {
    A, B, C,
    _PRODUCT_COUNT
};

static const char *product_str[_PRODUCT_COUNT] = {"A", "B", "C"};

#define PHASE_COUNT 6

static const enum place production[_PRODUCT_COUNT][PHASE_COUNT] = {
    {NUZKY, VRTACKA, OHYBACKA, SVARECKA, VRTACKA, LAKOVNA},
    {VRTACKA, NUZKY, FREZA, VRTACKA, LAKOVNA, SROUBOVAK},
    {FREZA, VRTACKA, SROUBOVAK, VRTACKA, FREZA, LAKOVNA}
};

static const int work_time[_PLACE_COUNT] = {
    100, 200, 150, 300, 400, 250, 500
};

typedef struct worker {
    char *name;
    enum place specialization;
    bool stop;
    pthread_t thread;
    struct worker *next;
} worker_t;

static worker_t *workers = NULL;
static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t changed = PTHREAD_COND_INITIALIZER;

/* Pocet stroju, obsazena mista a cekajici odebrani. */
static int places[_PLACE_COUNT];
static int occupied[_PLACE_COUNT];
static int pending_remove[_PLACE_COUNT];
static int parts[_PRODUCT_COUNT][PHASE_COUNT];
static int in_progress[_PRODUCT_COUNT][PHASE_COUNT];
static bool input_closed = false;

static int find_string(const char *const *array, int count, const char *value)
{
    for (int i = 0; i < count; i++) {
        if (strcmp(array[i], value) == 0)
            return i;
    }
    return -1;
}

static int free_places(enum place p)
{
    return places[p] - occupied[p];
}

static bool phase_possible(int product, int phase)
{
    enum place p = production[product][phase];
    if (places[p] <= pending_remove[p])
        return false;

    for (worker_t *w = workers; w != NULL; w = w->next) {
        if (w->specialization == p && !w->stop)
            return true;
    }
    return false;
}

/* Po EOF zjistime, jestli je dana profese jeste potreba. */
static bool profession_needed(enum place p)
{
    for (int product = 0; product < _PRODUCT_COUNT; product++) {
        for (int start = 0; start < PHASE_COUNT; start++) {
            bool can_continue = in_progress[product][start] > 0;

            /* Pockame i na prave bezici praci stejne profese. */
            if (can_continue && production[product][start] == p)
                return true;

            if (parts[product][start] > 0 && phase_possible(product, start)) {
                if (production[product][start] == p)
                    return true;
                can_continue = true;
            }

            if (!can_continue)
                continue;

            for (int phase = start + 1; phase < PHASE_COUNT; phase++) {
                if (!phase_possible(product, phase))
                    break;
                if (production[product][phase] == p)
                    return true;
            }
        }
    }
    return false;
}

/* Prednost maji pozdejsi faze vyroby, potom poradi A, B, C. */
static bool find_work(enum place p, int *product, int *phase)
{
    if (free_places(p) <= 0)
        return false;

    for (int step = PHASE_COUNT - 1; step >= 0; step--) {
        for (int item = 0; item < _PRODUCT_COUNT; item++) {
            if (production[item][step] == p && parts[item][step] > 0) {
                *product = item;
                *phase = step;
                return true;
            }
        }
    }
    return false;
}

static void sleep_work(int milliseconds)
{
    struct timespec remaining = {
        .tv_sec = milliseconds / 1000,
        .tv_nsec = (long)(milliseconds % 1000) * 1000000L
    };

    while (nanosleep(&remaining, &remaining) == -1 && errno == EINTR) {
    }
}

static void *worker_main(void *data)
{
    worker_t *w = data;
    pthread_mutex_lock(&mutex);

    while (true) {
        int product;
        int phase;
        enum place p = w->specialization;

        if (w->stop || (input_closed && !profession_needed(p))) {
            w->stop = true;
            printf("%s goes home\n", w->name);
            fflush(stdout);
            pthread_cond_broadcast(&changed);
            break;
        }

        if (find_work(p, &product, &phase)) {
            parts[product][phase]--;
            in_progress[product][phase]++;
            occupied[p]++;

            printf("%s %s %s %d\n", w->name, place_str[p],
                   product_str[product], phase + 1);
            fflush(stdout);

            /* Behem prace nezamykame ostatni delniky. */
            pthread_mutex_unlock(&mutex);
            sleep_work(work_time[p]);
            pthread_mutex_lock(&mutex);

            occupied[p]--;
            in_progress[product][phase]--;
            /* Obsazeny stroj muzeme odebrat az po dokonceni operace. */
            if (pending_remove[p] > 0) {
                pending_remove[p]--;
                places[p]--;
            }

            if (phase == PHASE_COUNT - 1) {
                printf("done %s\n", product_str[product]);
                fflush(stdout);
            } else {
                parts[product][phase + 1]++;
            }

            pthread_cond_broadcast(&changed);
        } else {
            pthread_cond_wait(&changed, &mutex);
        }
    }

    pthread_mutex_unlock(&mutex);
    return NULL;
}

static void start_worker(const char *name, enum place p)
{
    worker_t *w = malloc(sizeof(*w));
    if (w == NULL) {
        fprintf(stderr, "Cannot allocate worker\n");
        return;
    }

    w->name = strdup(name);
    if (w->name == NULL) {
        free(w);
        fprintf(stderr, "Cannot allocate name\n");
        return;
    }

    w->specialization = p;
    w->stop = false;

    pthread_mutex_lock(&mutex);
    for (worker_t *other = workers; other != NULL; other = other->next) {
        if (strcmp(other->name, name) == 0) {
            fprintf(stderr, "Worker already exists: %s\n", name);
            pthread_mutex_unlock(&mutex);
            free(w->name);
            free(w);
            return;
        }
    }

    w->next = workers;
    workers = w;
    int result = pthread_create(&w->thread, NULL, worker_main, w);
    if (result != 0) {
        workers = w->next;
        fprintf(stderr, "Cannot start worker: %s\n", name);
        free(w->name);
        free(w);
    } else {
        pthread_cond_broadcast(&changed);
    }
    pthread_mutex_unlock(&mutex);
}

static void end_worker(const char *name)
{
    pthread_mutex_lock(&mutex);
    for (worker_t *w = workers; w != NULL; w = w->next) {
        if (strcmp(w->name, name) == 0) {
            w->stop = true;
            pthread_cond_broadcast(&changed);
            pthread_mutex_unlock(&mutex);
            return;
        }
    }
    pthread_mutex_unlock(&mutex);
    fprintf(stderr, "Unknown worker: %s\n", name);
}

static void change_place(enum place p, bool add)
{
    pthread_mutex_lock(&mutex);
    if (add) {
        places[p]++;
    } else if (free_places(p) > 0) {
        places[p]--;
    } else if (occupied[p] > pending_remove[p]) {
        pending_remove[p]++;
    }
    pthread_cond_broadcast(&changed);
    pthread_mutex_unlock(&mutex);
}

int main(void)
{
    char *line = NULL;
    size_t size = 0;

    while (getline(&line, &size, stdin) != -1) {
        char *saveptr = NULL;
        char *cmd = strtok_r(line, " \t\r\n", &saveptr);
        char *arg1 = strtok_r(NULL, " \t\r\n", &saveptr);
        char *arg2 = strtok_r(NULL, " \t\r\n", &saveptr);
        char *extra = strtok_r(NULL, " \t\r\n", &saveptr);

        if (cmd == NULL)
            continue;

        if (strcmp(cmd, "start") == 0 && arg1 && arg2 && !extra) {
            int p = find_string(place_str, _PLACE_COUNT, arg2);
            if (p >= 0)
                start_worker(arg1, p);
            else
                fprintf(stderr, "Unknown place: %s\n", arg2);
        } else if (strcmp(cmd, "make") == 0 && arg1 && !arg2) {
            int product = find_string(product_str, _PRODUCT_COUNT, arg1);
            if (product >= 0) {
                pthread_mutex_lock(&mutex);
                parts[product][0]++;
                pthread_cond_broadcast(&changed);
                pthread_mutex_unlock(&mutex);
            } else {
                fprintf(stderr, "Unknown product: %s\n", arg1);
            }
        } else if (strcmp(cmd, "end") == 0 && arg1 && !arg2) {
            end_worker(arg1);
        } else if (strcmp(cmd, "add") == 0 && arg1 && !arg2) {
            int p = find_string(place_str, _PLACE_COUNT, arg1);
            if (p >= 0)
                change_place(p, true);
            else
                fprintf(stderr, "Unknown place: %s\n", arg1);
        } else if (strcmp(cmd, "remove") == 0 && arg1 && !arg2) {
            int p = find_string(place_str, _PLACE_COUNT, arg1);
            if (p >= 0)
                change_place(p, false);
            else
                fprintf(stderr, "Unknown place: %s\n", arg1);
        } else {
            fprintf(stderr, "Invalid command\n");
        }
    }

    /* Po uzavreni vstupu nechame dokoncit dostupnou praci. */
    free(line);
    pthread_mutex_lock(&mutex);
    input_closed = true;
    pthread_cond_broadcast(&changed);
    pthread_mutex_unlock(&mutex);

    for (worker_t *w = workers; w != NULL; w = w->next)
        pthread_join(w->thread, NULL);

    while (workers != NULL) {
        worker_t *next = workers->next;
        free(workers->name);
        free(workers);
        workers = next;
    }

    pthread_cond_destroy(&changed);
    pthread_mutex_destroy(&mutex);
    return 0;
}
